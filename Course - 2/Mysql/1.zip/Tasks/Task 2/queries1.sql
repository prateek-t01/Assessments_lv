create table employees (
	employee_id int not null, 
	first_name varchar(10) not null, 
    last_name varchar(10) not null, 
    email varchar(25) not null,
    department varchar(15),
    salary int not null,
    hire_Date date not null
    );
    
-- 1. Inserting Values
insert into employees 
(employee_id, first_name, last_name, email, department, salary, hire_date)
VALUES 
(101, 'John', 'Doe', 'johndoe@example.com', 'IT', 60000, '2023-01-10'),
(102, 'Jane', 'Smith', 'janesmith@example.com', 'HR', 50000, '2023-02-20'),
(103, 'Emily', 'Johnson', 'emilyj@example.com', 'Finance', 55000, '2023-03-15'),
(104, 'Michael', 'Brown', 'mbrown@example.com', 'IT', 62000, '2023-04-25'),
(105, 'Linda', 'Davis', 'ldavis@example.com', 'Marketing', 58000, '2023-05-30');

-- 2. Update IT Department Salary

update employees
set salary = (salary + (salary * 0.1))
where department = "IT";

select * from employees;

-- 3 Delete employee record where employee_id = 101

delete from employees where employee_id = 101;

select * from employees;

-- 4. Select all employees in HR department and order them by last name in ascending order.

select * from employees where department = "HR" ORDER BY last_name;

-- 5. Average salary of all employees in Finanace Department

SELECT AVG(salary) FROM employees WHERE department = "finance";

-- 6 

CREATE TABLE departments (department_name VARCHAR(20) PRIMARY KEY, manager_id INT);

select * from departments;

-- 7 Alter the department table to add a new column named hire_Date of type date.

alter table departments 
add hire_date DATE;

select * from departments;

-- 8 drop departments

drop table departments;

-- 9 add two new columns to employees and then rollback

insert into employees(employee_id, first_name, last_name, email, department, salary, hire_date)
values (106, "Tusar", "L", "tushar.l@xyz.com", 'DSA', 50000, '2024-03-25'),
(107, "Kartik", "B", "kartik.b@xyz.com", 'DS', 50000, '2024-03-25');

select * from employees;

-- 9
commit;

start TRANSACTION;

delete from employees where employee_id = 107;
select * from employees;
rollback;

-- 10 transaction that UPDATES the department of an employee and then COMMIT the transaction.

commit;

select * from employees;

start transaction;
update employees 
set salary = salary - 10000
where department  = 'IT';

Rollback;

select * from employees;
    