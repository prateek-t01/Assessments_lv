create table products (
product_id int not null,
name varchar(20) not null,
category varchar(10) not null,
price float(2) not null,
stock_quantity int,
supplier_id INT
);

-- 1. Insert values.
insert into products 
values 
(201, 'Bluetooth Headphones', 'Electronics', 89.99, 150, 2),
(202, 'Paperback Book', 'Books', 15.99, 200, 3),
(203, '4K LED TV', 'Electronics', 399.99, 50, 2),
(204, 'Leather Wallet', 'Accessories', 24.99, 100, 4),
(205, 'Stainless Steel Mug', 'Home Goods', 12.99, 150, 5);

-- 2 update

update products
set stock_quantity = stock_quantity + 50
where category = 'Books';

select * from products;

-- 4 between 50 and 100 dollars.
select * from products 
where price between 50 AND 100;

-- 5 highest value product in each category

SELECT category, name, price
FROM products
WHERE (category, price) IN (SELECT category, MAX(price) FROM products GROUP BY category);

-- 6. 

create table suppliers (supplier_id int Primary key, name varchar(40), email varchar(30));

-- 7. 
alter table products
add column description text;

select * from products;

 -- 8.
 drop table suppliers;
 
 -- 9. 
 commit;
 
 start transaction;
 
INSERT INTO products (product_id, name, category, price, stock_quantity, supplier_id) 
VALUES (206, 'Steel Thali', 'Kitchen', 249.99, 200, 5);

 
 update products 
 set stock_quantity = 10 where price > 300;
 
 select * from products;
 
 rollback;
 
 select * from products;
 
 -- 10
 
 commit;
 
 select * from products;
 
delete from products where product_id = 203;

select * from products;

commit;

select * from  products;

