create table customers (
customer_id int primary key not null,
first_name varchar(25), 
last_name varchar(30),
email varchar(50) not null,
address varchar(60) not null,
city varchar (40),
country varchar (5) not null);

insert into customers ( customer_id, first_name, last_name, email, address, city, country )
values(301, 'Alice', 'Johnson', 'alice.johnson@example.com', '123 Mapple Street', 'springfield', 'USA'),
(302, 'Bob', 'Smith', 'bobsmiht@example.com', '456 Ook Road', 'New York', 'USA'),
(303, 'Charlie', 'Brown', 'charliebrown@example.com', '789 Pine Avenue', 'Springfield', 'USA'),
(304, 'Dana', 'White', 'danaw@example.com', '1012 Elm Street', 'New York', 'USA'),
(305, 'Evan', 'Davis', 'evandavis@example.com', '1314 Birch Lane', 'Chicago', 'USA');


-- 2 update

update customers
set email = 'alice.j@example.com'
where customer_id = 301;

-- 4
select * from products where city = 'New York';

-- 5 highest value product in each category

SELECT Country, COUNT(*) AS TotalCustomers
FROM Customers
GROUP BY Country
ORDER BY TotalCustomers DESC;


-- 6. 
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    amount DECIMAL,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- 7. 
ALTER TABLE customers
ADD COLUMN phone_number int;
 
 -- 9.
 start TRANSACTION;
INSERT INTO customers (customer_id, customer_name, email)
VALUES (308, 'Robin Chaw', 'Robin.c@example.com');
    INSERT INTO orders (order_id, customer_id, order_date, amount)
    VALUES (111, 308, '2024-03-25', 100.00);
COMMIt;
rollback;

 
 -- 10
 
start TRANSACTION;
UPDATE customers
SET address = 'New Address'
WHERE customer_id =304;
DELETE FROM customers
WHERE customer_id NOT IN (
    SELECT DISTINCT customer_id
    FROM orders
);
commit;



