-- OVER (PARTITION BY partition_column ORDER BY order_column): 
-- This part defines the window frame by partitioning the rows 
-- based on the partition_column and ordering them within each 
-- partition based on the order_column.

-- CUME_DIST() compares value of current row with the value of 
-- all the other rows in the partition nad gives a value of it 
-- in between 0 and 1.
-- its like "you scored better than 70% of your mates", 
-- if your cume_dist is 0.70)

-- DENSE RANK - To be used with ORDER BY clause.ALTER
-- DENSE RANK() over (ORDER BY col),

-- FIRST_VALUE - Gives first value of the partition 
-- in all the rows of that partition.
-- FIRST_VALUE(col) OVER w AS 'ALIAS'
-- WINDOW w AS (PARTITION BY category_Related_col, 
-- ORDER BY some_col ROWS UNBOUNDED PRECEDING

-- LAST_VALUE - Gives the value of expression 
-- or specified col from the last value of the 
-- partition.
-- LAST_VALUE(col) OVER (PARTITION BY 
-- partition_column ORDER BY order_column 
-- ROWS BETWEEN UNBOUNDED PRECEDING AND 
-- UNBOUNDED FOLLOWING) AS last_value_column

-- LAG - Will give previous value of current row
-- LAG(col, n) OVER (ORDER BY some_col) AS 'ALIAS'
-- n = number parameter specifies that you want 
-- to retrieve the value of col from the row 
-- that precedes the current row by nth position.

-- LEAD(col, n) OVER (ORDER BY order_column) AS 'ALIAS'
-- LEAD(col, n) retrieves the value of col from 
-- the row that follows the current row by nth 
-- position.

-- NTH_VALUE (col, n) OVER (ORDER BY order_col) AS 'ALIAS'
-- gives nth value from the specified 'n' inside the 
-- partition. IF nth position is beyond the partition
-- window, the NULL is returned.

-- NTILE(n) - Divides a partition into N groups 
-- (buckets), assigns each row in the partition 
-- its bucket number, and returns the bucket 
-- number of the current row within its partition.
-- Will devide like = 
-- (total_no_of_rows/ntile_n) = no. of buckets

-- ROW NUMBER - Returns the number of the current row within 
-- its partition. Rows numbers range from 1 to the number of 
-- partition rows.

-- RANK

