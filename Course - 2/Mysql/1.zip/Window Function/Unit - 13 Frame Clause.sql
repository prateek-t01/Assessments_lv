-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Frame Clause
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Example 1: Aggregate function: Max with Partition Over Month and Year
-- Frame Clause ROWS BETWEEN N PRECEDING AND N FOLLOWING
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~

select 
	month(Sales_Date),
	Year(Sales_Date),
	prod.Product_Group_Code, 
	sales.Product_Code,
	sales_quantity, 
	min(sales_quantity) OVER (PARTITION BY  month(Sales_Date),Year(Sales_Date) ORDER BY month(Sales_Date)) min_quntinty,
	max(sales_quantity) OVER (PARTITION BY  month(Sales_Date),Year(Sales_Date) ORDER BY month(Sales_Date)) max_quantity,
	avg(sales_quantity) OVER (PARTITION BY  month(Sales_Date),Year(Sales_Date) ORDER BY month(Sales_Date)) average_quantity ,
	min(sales_quantity) OVER (PARTITION BY  month(Sales_Date),Year(Sales_Date) ORDER BY month(Sales_Date) ROWS BETWEEN 5 PRECEDING AND 5 FOLLOWING ) min_quntinty_Within_10_Entries,
	max(sales_quantity) OVER (PARTITION BY  month(Sales_Date),Year(Sales_Date) ORDER BY month(Sales_Date) ROWS BETWEEN 5 PRECEDING AND 5 FOLLOWING ) max_quantity_Within_10_Entries,
	avg(sales_quantity) OVER (PARTITION BY  month(Sales_Date),Year(Sales_Date) ORDER BY month(Sales_Date) ROWS BETWEEN 5 PRECEDING AND 5 FOLLOWING ) average_quantity_Within_10_Entries
from DSAI_T_Sales sales 
JOIN DSAI_M_Product prod on (prod.Product_Code = sales.Product_Code);

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
-- Example 2 : Sum with Frame Clause
-- Frame Clause ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~ ***************

select Sales_Date,prod.Product_Group_Code, sales.Product_Code,sales_quantity, 
sum(sales_quantity) OVER (PARTITION BY Product_Group_Code ORDER BY prod.Product_Group_Code

ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING ) Total_sales_of_group_within_Frame 

from DSAI_T_Sales sales 
JOIN DSAI_M_Product prod on (prod.Product_Code = sales.Product_Code)
where sales_date between '2010-01-01' and '2010-01-31';


-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Example 3: Sum with Frame Clause
-- Frame Clause RROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~

select Sales_Date,prod.Product_Group_Code, sales.Product_Code,sales_quantity, 
sum(sales_quantity) OVER (PARTITION BY Product_Group_Code ORDER BY prod.Product_Group_Code

ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW ) Total_sales_of_group_within_Frame  -- ***************** Like a Running Total *****************

from DSAI_T_Sales sales 
JOIN DSAI_M_Product prod on (prod.Product_Code = sales.Product_Code)
where sales_date between '2010-01-01' and '2010-01-31';

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Example 3: Sum with Frame Clause
-- Frame Clause ROWS BETWEEN N PRECEDING AND N FOLLOWING
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~

select 
	Sales_Date,
	prod.Product_Group_Code, 
	sales.Product_Code,
	sales_quantity, 
	sum(sales_quantity) OVER (PARTITION BY Product_Group_Code ORDER BY prod.Product_Group_Code
	ROWS BETWEEN 2 PRECEDING AND 2 FOLLOWING ) Total_sales_of_group_within_Frame 
from 
	DSAI_T_Sales sales 
JOIN DSAI_M_Product prod on (prod.Product_Code = sales.Product_Code)
where sales_date between '2010-01-01' and '2010-01-31';


-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Example 4: Sum with Frame Clause
-- Frame Clause ROWS BETWEEN N PRECEDING AND CURRENT ROW
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~

select Sales_Date,prod.Product_Group_Code, sales.Product_Code,sales_quantity, 
sum(sales_quantity) OVER (PARTITION BY Product_Group_Code ORDER BY prod.Product_Group_Code

ROWS BETWEEN 2 PRECEDING AND CURRENT ROW ) Total_sales_of_group_within_Frame 

from DSAI_T_Sales sales 
JOIN DSAI_M_Product prod on (prod.Product_Code = sales.Product_Code)
where sales_date between '2010-01-01' and '2010-01-31';	



-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Example 6: 
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~
SELECT Product_Code, Sales_date, Sales_quantity,
          RANK() OVER (
              PARTITION BY Product_Code
              ORDER BY Sales_quantity DESC
              ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
          ) AS sales_quantity_rank
   FROM DSAI_T_Sales
