
-- Example 1
/* 
You're tasked with ranking employees based on their salaries, 
but if two employees have the same salary, they should be assigned the same rank,
and the next employee should receive a rank one higher. How can you accomplish this
*/

SELECT employee_name,
       salary,
       DENSE_RANK() OVER (ORDER BY salary DESC) AS ranks
FROM employees;

-- Example 2
/*
You're tasked with ranking students based on their exam scores, but you want to handle ties 
by giving the same rank to tied students and without leaving a gap before the next rank. How can you do this?
*/
SELECT student_name,
       exam_score,
       DENSE_RANK() OVER (ORDER BY exam_score DESC) AS ranks
FROM students;

-- Example 3
/* Assign a rank without gap to each student based on their exam id, ordered by their exam scores */

SELECT DENSE_RANK() OVER (PARTITION BY exam_id ORDER BY exam_score DESC) AS ranks,
student_name, exam_id, exam_score
FROM students;

-- Example 4
/* Assign a rank without Gap to each sales representative based on their total sales amounts */

SELECT rep_name, sales_amount, DENSE_RANK() OVER (ORDER BY sales_amount DESC) AS ranks 
FROM sales_representatives;

-- Example 5
/* You're required to rank sales transactions based on their sales amounts, but if two transactions have the same 
sales amount, they should be given the same rank, and the next transaction should receive a rank one higher. 
How can you accomplish this?
*/
    
SELECT 
	product_name,
   price,
   DENSE_RANK() OVER (ORDER BY price DESC) AS ranks
FROM products;

