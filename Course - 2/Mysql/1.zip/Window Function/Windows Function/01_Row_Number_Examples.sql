
-- Example : 1

##
##
##  ROW_NUMBER() ==> Ex:  Number 1 product, Number 1 student
##  ROW_NUMBER() ==> Within a Subset  
##

-- How will you assign a unique row number to each employee based on their salary in descending order ?

SELECT ROW_NUMBER() OVER (ORDER BY salary DESC) AS row_num, employee_name, salary
FROM employees;

-- Example : 2
-- Table Name : sales
-- How will you  identify the top-performing products based on the sales amount ?

SELECT ROW_NUMBER() OVER (ORDER BY sales_amount DESC) AS row_num, product_name, sales_amount
FROM sales;

-- Example : 3
-- Table Name : students
-- Assign a unique row number to each student based on their exam scores

SELECT ROW_NUMBER() OVER (PARTITION BY exam_id ORDER BY exam_score DESC) AS row_num, student_name, exam_score,exam_id 
FROM students;

-- Example : 4 
-- Assign Row number based on their prices 

SELECT ROW_NUMBER() OVER (ORDER BY price) AS row_num, product_name, price FROM products;

-- Example : 5
-- rank customers based on their total orders, but you want to restart the ranking for each country they belong to.

SELECT ROW_NUMBER() OVER (PARTITION BY country ORDER BY total_orders DESC) AS row_num, customer_name, country, total_orders
FROM customers;



