-- Example_1
##Calculate the average salary of all employees from the employee_salaries table##
SELECT AVG(salary) AS average_salary FROM employee_salaries_details;

-- Example_2
-- Find the average price of all products in the product_prices table
SELECT AVG(price) AS average_price FROM product_prices;

-- Example_3
-- Calculate the average score achieved by all students in the student_scores table
SELECT AVG(exam_score) AS average_score FROM students;

-- Example_4
-- Aggregate Functions: count()
-- Count the total number of employees in the employees table
SELECT COUNT(*) AS total_employees FROM employees;

-- Example_5
-- Count the total number of orders placed in the orders table
SELECT COUNT(*) AS total_orders FROM customer_orders;

-- Example_6
-- Count the total number of products available in the products table
SELECT COUNT(*) AS total_products FROM products;

-- Example_7
-- Aggregate Functions: max() --
-- Find the latest order date in the orders table
SELECT MAX(order_date) AS latest_order_date FROM customer_orders;

-- Example_8
-- Find the highest product price in the products table
SELECT MAX(price) AS highest_product_price FROM products;

-- Example_9
-- Find the hire date of the oldest employee in the employees table
SELECT MAX(hire_date) AS oldest_employee_hire_date FROM employees_hire;

-- Example_10
-- Aggregate Functions: min()
-- Find the earliest order date in the orders table
SELECT MIN(order_date) AS earliest_order_date FROM customer_orders;

-- Example_11
-- Find the lowest product price in the products table
SELECT MIN(price) AS lowest_product_price FROM products_2;

-- Example_12
-- Find the birth date of the youngest employee in the employees table
SELECT MIN(birth_date) AS youngest_employee_birth_date FROM employees_DOB;

-- Example_13
-- Aggregate Functions: sum()
-- Calculate the total sales amount from the sales table
SELECT SUM(quantity * unit_price) AS total_sales_amount FROM sales_quantity;

-- Example_14
-- Calculate the total expenses incurred from the expenses table
SELECT SUM(amount) AS total_expenses FROM expenses;

-- Example_15
-- Calculate the total value of all orders in the orders table
SELECT SUM(order_amount) AS total_order_value FROM customer_orders;













