
-- Example : 1
-- How will you order the employee wtih number based on their salary in descending order ?

SELECT  employee_name, salary, Rank() OVER (ORDER BY salary DESC) AS SAL_RANK
FROM employees;

-- Example : 2
-- How will you  identify the top-performing products based on the sales amount ?

SELECT product_name, sales_amount, Rank() OVER (ORDER BY sales_amount DESC) AS PRD_RANK 
FROM sales;

-- Example : 3
-- How will assign a unique number to each student based on their exam scores

SELECT student_name, exam_score,exam_id, ROW_NUMBER() OVER (PARTITION BY exam_id ORDER BY exam_score DESC) AS EXAM_RABK
FROM students;


-- Example : 4 
-- Assign Row number based on their prices 

SELECT product_name, price, Rank() OVER (ORDER BY price DESC) AS ranks FROM products;

-- Example : 5
-- rank customers based on their total orders, but you want to restart the ranking for each country they belong to.

SELECT customer_name, country, total_orders, Rank() OVER (PARTITION BY country ORDER BY total_orders DESC) AS ranks
FROM customers;



