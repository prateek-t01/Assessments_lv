-- Analytic Functions: lead()
-- Calculate the difference in sales amount between each transaction and the next transaction in the sales table

SELECT transaction_id, transaction_date, sales_amount,
       LEAD(sales_amount) OVER (ORDER BY transaction_date) AS next_sales_amount,
       LEAD(sales_amount) OVER (ORDER BY transaction_date) - sales_amount AS sales_growth
FROM sales_transaction;

-- Determine the change in inventory quantity between each transaction and the next transaction in the inventory table
SELECT product_id, transaction_date, quantity,
       LEAD(quantity) OVER (PARTITION BY product_id ORDER BY transaction_date) AS next_quantity,
       LEAD(quantity) OVER (PARTITION BY product_id ORDER BY transaction_date) - quantity AS quantity_change
FROM inventory;

-- Calculate the difference in stock prices between each day and the next day in the stocks table
SELECT stock_id, date, price,
       LEAD(price) OVER (PARTITION BY stock_id ORDER BY date) AS next_day_price,
       LEAD(price) OVER (PARTITION BY stock_id ORDER BY date) - price AS price_change
FROM stocks;

-- Calculate the difference in page views between each visit and the next visit in the web_traffic table

SELECT page_id, visit_date, page_views,
       LEAD(page_views) OVER (PARTITION BY page_id ORDER BY visit_date) AS next_day_page_views,
       LEAD(page_views) OVER (PARTITION BY page_id ORDER BY visit_date) - page_views AS page_views_change
FROM web_traffic;


-- Determine the change in performance rating between each evaluation and the next evaluation in the employee_performance table

SELECT employee_id, evaluation_date, performance_rating,
       LEAD(performance_rating) OVER (PARTITION BY employee_id ORDER BY evaluation_date) AS next_evaluation_rating,
       LEAD(performance_rating) OVER (PARTITION BY employee_id ORDER BY evaluation_date) - performance_rating AS rating_change
FROM employee_performance;

## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~``
##
-- Analytic Functions: lag()
##
## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~``

-- Calculate the difference in sales amount between each transaction and the previous transaction in the sales table

SELECT transaction_id, transaction_date, sales_amount,
       LAG(sales_amount) OVER (ORDER BY transaction_date) AS prev_sales_amount,
       sales_amount - LAG(sales_amount) OVER (ORDER BY transaction_date) AS sales_difference
FROM sales_transaction;

-- Determine the change in inventory quantity between each transaction and the previous transaction in the inventory table

SELECT product_id, transaction_date, quantity,
       LAG(quantity) OVER (PARTITION BY product_id ORDER BY transaction_date) AS prev_quantity,
       quantity - LAG(quantity) OVER (PARTITION BY product_id ORDER BY transaction_date) AS quantity_change
FROM inventory;

-- Calculate the difference in stock prices between each day and the previous day in the stocks table
SELECT stock_id, date, price,
       LAG(price) OVER (PARTITION BY stock_id ORDER BY date) AS prev_day_price,
       price - LAG(price) OVER (PARTITION BY stock_id ORDER BY date) AS price_difference
FROM stocks;

-- Calculate the difference in page views between each visit and the previous visit in the web_traffic table
SELECT page_id, visit_date, page_views,
       LAG(page_views) OVER (PARTITION BY page_id ORDER BY visit_date) AS prev_page_views,
       page_views - LAG(page_views) OVER (PARTITION BY page_id ORDER BY visit_date) AS page_views_difference
FROM web_traffic;

-- Determine the change in performance rating between each evaluation and the previous evaluation in the employee_performance table
SELECT employee_id, evaluation_date, performance_rating,
       LAG(performance_rating) OVER (PARTITION BY employee_id ORDER BY evaluation_date) AS prev_evaluation_rating,
       performance_rating - LAG(performance_rating) OVER (PARTITION BY employee_id ORDER BY evaluation_date) AS rating_difference
FROM employee_performance;

## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`
##  NTILE()
##
## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`


-- Divide students into quartiles ( 4 ) based on their exam scores in the exam_scores table

SELECT student_id, student_name, exam_score,
       NTILE(4) OVER (ORDER BY exam_score DESC) AS quartile
FROM students;

-- Divide sales representatives into quintiles ( 5 equal parts) based on their total sales in the sales_representatives table

SELECT rep_id, rep_name, sales_amount,
       NTILE(5) OVER (ORDER BY sales_amount DESC) AS quintile
FROM sales_representatives;

-- Categorize employees into quintiles based on their salaries in the employees table

SELECT employee_id, employee_name, salary,
       NTILE(5) OVER (ORDER BY salary DESC) AS quintile
FROM employees;

-- Divide customers into quartiles (4)) based on their total spending in the customers table

SELECT customer_id, customer_name, total_orders,
       NTILE(4) OVER (ORDER BY total_orders DESC) AS quartile
FROM customers;

##
##  first_value()
##
##


-- Analytic Functions: first_value()
-- Find the initial salary and the most recent salary for each employee in the employee_salaries table
SELECT 
    employee_id,
    employee_name,
    FIRST_VALUE(salary) OVER (PARTITION BY employee_id ORDER BY salary_date) AS initial_salary,
    FIRST_VALUE(salary) OVER (PARTITION BY employee_id ORDER BY salary_date DESC) AS recent_salary
FROM employee_salaries_details;

-- Find the initial price and the most recent price for each product in the product_prices table
SELECT 
    product_id,
    product_name,
    FIRST_VALUE(price) OVER (PARTITION BY product_id ORDER BY price_date) AS initial_price,
    FIRST_VALUE(price) OVER (PARTITION BY product_id ORDER BY price_date DESC) AS recent_price
FROM product_prices;

##
##
## Explian This 
##

SELECT 
    employee_id,
    employee_name,
    LAST_VALUE(salary) OVER (PARTITION BY employee_id ORDER BY salary_date RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS recent_salary
FROM employee_salaries_new;


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@2

SELECT 
    customer_id,
    FIRST_VALUE(order_amount) OVER (PARTITION BY customer_id ORDER BY order_date) AS initial_order_amount,
    FIRST_VALUE(order_amount) OVER (PARTITION BY customer_id ORDER BY order_date DESC) AS recent_order_amount
FROM customer_orders;

--
--
SELECT 
    stock_id,
    FIRST_VALUE(price) OVER (PARTITION BY stock_id ORDER BY price_date) AS initial_price,
    FIRST_VALUE(price) OVER (PARTITION BY stock_id ORDER BY price_date DESC) AS recent_price
FROM stock_prices;
--
--
SELECT 
    account_id,
    FIRST_VALUE(balance) OVER (PARTITION BY account_id ORDER BY balance_date) AS initial_balance,
    FIRST_VALUE(balance) OVER (PARTITION BY account_id ORDER BY balance_date DESC) AS recent_balance
FROM account_balances;

--
--
SELECT 
    employee_id,
    employee_name,
    FIRST_VALUE(salary) OVER (PARTITION BY employee_id ORDER BY salary_date) AS initial_salary,
    LAST_VALUE(salary) OVER (PARTITION BY employee_id ORDER BY salary_date RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS recent_salary
FROM employee_salaries_new;

SELECT 
    account_id,
    FIRST_VALUE(balance) OVER (PARTITION BY account_id ORDER BY balance_date) AS initial_balance,
    LAST_VALUE(balance) OVER (PARTITION BY account_id ORDER

 BY balance_date RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS recent_balance
FROM account_balances;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@2

INSERT INTO customer_orders (order_id, customer_id, order_amount, order_date)
VALUES
    (1, 101, 1000.00, '2024-01-01'),
    (2, 102, 1500.00, '2024-01-01'),
    (3, 103, 2000.00, '2024-01-01'),
    (1, 101, 1200.00, '2024-02-01'),
    (2, 102, 1800.00, '2024-02-01'),
    (3, 103, 2200.00, '2024-02-01'),
    (1, 101, 1300.00, '2024-03-01'),
    (2, 102, 1700.00, '2024-03-01'),
    (3, 103, 2100.00, '2024-03-01');

SELECT 
    customer_id,
    FIRST_VALUE(order_amount) OVER (PARTITION BY customer_id ORDER BY order_date) AS initial_order_amount,
    FIRST_VALUE(order_amount) OVER (PARTITION BY customer_id ORDER BY order_date DESC) AS recent_order_amount
FROM customer_orders;

-- Find the initial balance and the most recent balance for each account in the account_balances table
CREATE TABLE account_balances (
    account_id INT,
    balance DECIMAL(10, 2),
    balance_date DATE
);

INSERT INTO account_balances (account_id, balance, balance_date)
VALUES
    (1, 5000.00, '2024-01-01'),
    (2, 7500.00, '2024-01-01'),
    (3, 10000.00, '2024-01-01'),
    (1, 5200.00, '2024-02-01'),
    (2, 7800.00, '2024-02-01'),
    (3, 10200.00, '2024-02-01'),
    (1, 5300.00, '2024-03-01'),
    (2, 7700.00, '2024-03-01'),
    (3, 10100.00, '2024-03-01');

SELECT 
    account_id,
    FIRST_VALUE(balance) OVER (PARTITION BY account_id ORDER BY balance_date) AS initial_balance,
    FIRST_VALUE(balance) OVER (PARTITION BY account_id ORDER BY balance_date DESC) AS recent_balance
FROM account_balances;

-- Find the initial price and the most recent price for each stock in the stock_prices table
CREATE TABLE stock_prices (
    stock_id INT,
    price DECIMAL(10, 2),
    price_date DATE
);

INSERT INTO stock_prices (stock_id, price, price_date)
VALUES
    (1, 100.00, '2024-01-01'),
    (2, 150.00, '2024-01-01'),
    (3, 200.00, '2024-01-01'),
    (1, 110.00, '2024-02-01'),
    (2, 160.00, '2024-02-01'),
    (3, 220.00, '2024-02-01'),
    (1, 120.00, '2024-03-01'),
    (2, 170.00, '2024-03-01'),
    (3, 230.00, '2024-03-01');


SELECT 
    stock_id,
    FIRST_VALUE(price) OVER (PARTITION BY stock_id ORDER BY price_date) AS initial_price,
    FIRST_VALUE(price) OVER (PARTITION BY stock_id ORDER BY price_date DESC) AS recent_price
FROM stock_prices;

-- Analytic Functions: last_value()
-- Find the initial salary and the most recent salary for each employee in the employee_salaries table
CREATE TABLE employee_salaries_new (
    employee_id INT,
    employee_name VARCHAR(50),
    salary DECIMAL(10, 2),
    salary_date DATE
);

INSERT INTO employee_salaries_new (employee_id, employee_name, salary, salary_date)
VALUES
    (1, 'Alice', 50000.00, '2024-01-01'),
    (2, 'Bob', 60000.00, '2024-01-01'),
    (3, 'Charlie', 55000.00, '2024-01-01'),
    (1, 'Alice', 52000.00, '2024-02-01'),
    (2, 'Bob', 62000.00, '2024-02-01'),
    (3, 'Charlie', 58000.00, '2024-02-01'),
    (1, 'Alice', 55000.00, '2024-03-01'),
    (2, 'Bob', 63000.00, '2024-03-01'),
    (3, 'Charlie', 59000.00, '2024-03-01');

SELECT 
    employee_id,
    employee_name,
    FIRST_VALUE(salary) OVER (PARTITION BY employee_id ORDER BY salary_date) AS initial_salary,
    LAST_VALUE(salary) OVER (PARTITION BY employee_id ORDER BY salary_date RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS recent_salary
FROM employee_salaries_new;
-- Find the initial price and the most recent price for each product in the product_prices table
CREATE TABLE product_prices (
    product_id INT,
    product_name VARCHAR(50),
    price DECIMAL(10, 2),
    price_date DATE
);

INSERT INTO product_prices (product_id, product_name, price, price_date)
VALUES
    (1, 'Laptop', 1200.00, '2024-01-01'),
    (2, 'Phone', 800.00, '2024-01-01'),
    (3, 'Tablet', 600.00, '2024-01-01'),
    (1, 'Laptop', 1100.00, '2024-02-01'),
    (2, 'Phone', 750.00, '2024-02-01'),
    (3, 'Tablet', 550.00, '2024-02-01'),
    (1, 'Laptop', 1000.00, '2024-03-01'),
    (2, 'Phone', 700.00, '2024-03-01'),
    (3, 'Tablet', 500.00, '2024-03-01');

SELECT 
    product_id,
    product_name,
    FIRST_VALUE(price) OVER (PARTITION BY product_id ORDER BY price_date) AS initial_price,
    LAST_VALUE(price) OVER (PARTITION BY product_id ORDER BY price_date RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS recent_price
FROM product_prices;
-- Find the initial order amount and the most recent order amount for each customer in the customer_orders table
CREATE TABLE customer_orders (
    order_id INT,
    customer_id INT,
    order_amount DECIMAL(10, 2),
    order_date DATE
);

INSERT INTO customer_orders (order_id, customer_id, order_amount, order_date)
VALUES
    (1, 101, 1000.00, '2024-01-01'),
    (2, 102, 1500.00, '2024-01-01'),
    (3, 103, 2000.00, '2024-01-01'),
    (1, 101, 1200.00, '2024-02-01'),
    (2, 102, 1800.00, '2024-02-01'),
    (3, 103, 2200.00, '2024-02-01'),
    (1, 101, 1300.00, '2024-03-01'),
    (2, 102, 1700.00, '2024-03-01'),
    (3, 103, 2100.00, '2024-03-01');

SELECT 
    customer_id,
    FIRST_VALUE(order_amount) OVER (PARTITION BY customer_id ORDER BY order_date) AS initial_order_amount,
    LAST_VALUE(order_amount) OVER (PARTITION BY customer_id ORDER BY order_date RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS recent_order_amount
FROM customer_orders;
-- Find the initial balance and the most recent balance for each account in the account_balances table
CREATE TABLE account_balances (
    account_id INT,
    balance DECIMAL(10, 2),
    balance_date DATE
);

INSERT INTO account_balances (account_id, balance, balance_date)
VALUES
    (1, 5000.00, '2024-01-01'),
    (2, 7500.00, '2024-01-01'),
    (3, 10000.00, '2024-01-01'),
    (1, 5200.00, '2024-02-01'),
    (2, 7800.00, '2024-02-01'),
    (3, 10200.00, '2024-02-01'),
    (1, 5300.00, '2024-03-01'),
    (2, 7700.00, '2024-03-01'),
    (3, 10100.00, '2024-03-01');

SELECT 
    account_id,
    FIRST_VALUE(balance) OVER (PARTITION BY account_id ORDER BY balance_date) AS initial_balance,
    LAST_VALUE(balance) OVER (PARTITION BY account_id ORDER

 BY balance_date RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS recent_balance
FROM account_balances;






