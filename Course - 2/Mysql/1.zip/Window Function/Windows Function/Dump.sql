-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: windows_example
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_balances`
--

DROP TABLE IF EXISTS `account_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_balances` (
  `account_id` int DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT NULL,
  `balance_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_balances`
--

LOCK TABLES `account_balances` WRITE;
/*!40000 ALTER TABLE `account_balances` DISABLE KEYS */;
INSERT INTO `account_balances` VALUES (1,5000.00,'2024-01-01'),(2,7500.00,'2024-01-01'),(3,10000.00,'2024-01-01'),(1,5200.00,'2024-02-01'),(2,7800.00,'2024-02-01'),(3,10200.00,'2024-02-01'),(1,5300.00,'2024-03-01'),(2,7700.00,'2024-03-01'),(3,10100.00,'2024-03-01');
/*!40000 ALTER TABLE `account_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_orders`
--

DROP TABLE IF EXISTS `customer_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_orders` (
  `order_id` int DEFAULT NULL,
  `customer_id` int DEFAULT NULL,
  `order_amount` decimal(10,2) DEFAULT NULL,
  `order_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_orders`
--

LOCK TABLES `customer_orders` WRITE;
/*!40000 ALTER TABLE `customer_orders` DISABLE KEYS */;
INSERT INTO `customer_orders` VALUES (1,101,1000.00,'2024-01-01'),(2,102,1500.00,'2024-01-01'),(3,103,2000.00,'2024-01-01'),(1,101,1200.00,'2024-02-01'),(2,102,1800.00,'2024-02-01'),(3,103,2200.00,'2024-02-01'),(1,101,1300.00,'2024-03-01'),(2,102,1700.00,'2024-03-01'),(3,103,2100.00,'2024-03-01');
/*!40000 ALTER TABLE `customer_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `customer_id` int DEFAULT NULL,
  `customer_name` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `total_orders` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Alice','USA',20),(2,'Bob','USA',15),(3,'Charlie','UK',25),(4,'David','UK',18);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_performance`
--

DROP TABLE IF EXISTS `employee_performance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_performance` (
  `employee_id` int DEFAULT NULL,
  `evaluation_date` date DEFAULT NULL,
  `performance_rating` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_performance`
--

LOCK TABLES `employee_performance` WRITE;
/*!40000 ALTER TABLE `employee_performance` DISABLE KEYS */;
INSERT INTO `employee_performance` VALUES (1,'2024-01-01',4),(2,'2024-01-05',3),(1,'2024-01-10',5),(2,'2024-01-15',4);
/*!40000 ALTER TABLE `employee_performance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_salaries_details`
--

DROP TABLE IF EXISTS `employee_salaries_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_salaries_details` (
  `employee_id` int DEFAULT NULL,
  `employee_name` varchar(50) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `salary_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_salaries_details`
--

LOCK TABLES `employee_salaries_details` WRITE;
/*!40000 ALTER TABLE `employee_salaries_details` DISABLE KEYS */;
INSERT INTO `employee_salaries_details` VALUES (1,'Alice',50000.00,'2024-01-01'),(2,'Bob',60000.00,'2024-01-01'),(3,'Charlie',55000.00,'2024-01-01'),(1,'Alice',52000.00,'2024-02-01'),(2,'Bob',62000.00,'2024-02-01'),(3,'Charlie',58000.00,'2024-02-01'),(1,'Alice',55000.00,'2024-03-01'),(2,'Bob',63000.00,'2024-03-01'),(3,'Charlie',59000.00,'2024-03-01');
/*!40000 ALTER TABLE `employee_salaries_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `employee_id` int DEFAULT NULL,
  `employee_name` varchar(50) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'John',50000.00),(2,'Jane',60000.00),(3,'Doe',55000.00),(4,'Smith',60000.00);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees_dob`
--

DROP TABLE IF EXISTS `employees_dob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees_dob` (
  `employee_id` int DEFAULT NULL,
  `employee_name` varchar(50) DEFAULT NULL,
  `birth_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_dob`
--

LOCK TABLES `employees_dob` WRITE;
/*!40000 ALTER TABLE `employees_dob` DISABLE KEYS */;
INSERT INTO `employees_dob` VALUES (1,'Alice','1990-05-15'),(2,'Bob','1985-08-20'),(3,'Charlie','1995-03-10'),(4,'David','1980-09-01'),(5,'Emma','1988-11-30');
/*!40000 ALTER TABLE `employees_dob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees_hire`
--

DROP TABLE IF EXISTS `employees_hire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees_hire` (
  `employee_id` int DEFAULT NULL,
  `employee_name` varchar(50) DEFAULT NULL,
  `hire_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_hire`
--

LOCK TABLES `employees_hire` WRITE;
/*!40000 ALTER TABLE `employees_hire` DISABLE KEYS */;
INSERT INTO `employees_hire` VALUES (1,'Alice','2010-01-15'),(2,'Bob','2015-05-20'),(3,'Charlie','2005-03-10'),(4,'David','2018-09-01'),(5,'Emma','2008-11-30');
/*!40000 ALTER TABLE `employees_hire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees_ratings`
--

DROP TABLE IF EXISTS `employees_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees_ratings` (
  `employee_id` int DEFAULT NULL,
  `employee_name` varchar(50) DEFAULT NULL,
  `performance_rating` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_ratings`
--

LOCK TABLES `employees_ratings` WRITE;
/*!40000 ALTER TABLE `employees_ratings` DISABLE KEYS */;
INSERT INTO `employees_ratings` VALUES (1,'Alice',4),(2,'Bob',3),(3,'Charlie',5),(4,'David',4);
/*!40000 ALTER TABLE `employees_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `expense_id` int DEFAULT NULL,
  `expense_type` varchar(50) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,'Office Supplies',200.00),(2,'Travel',500.00),(3,'Utilities',300.00),(4,'Meals',250.00),(5,'Rent',1500.00);
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `product_id` int DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `quantity` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'2024-01-01',100),(2,'2024-01-05',120),(1,'2024-01-10',90),(2,'2024-01-15',150);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_prices`
--

DROP TABLE IF EXISTS `product_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_prices` (
  `product_id` int DEFAULT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `price_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_prices`
--

LOCK TABLES `product_prices` WRITE;
/*!40000 ALTER TABLE `product_prices` DISABLE KEYS */;
INSERT INTO `product_prices` VALUES (1,'Laptop',1200.00,'2024-01-01'),(2,'Phone',800.00,'2024-01-01'),(3,'Tablet',600.00,'2024-01-01'),(1,'Laptop',1100.00,'2024-02-01'),(2,'Phone',750.00,'2024-02-01'),(3,'Tablet',550.00,'2024-02-01'),(1,'Laptop',1000.00,'2024-03-01'),(2,'Phone',700.00,'2024-03-01'),(3,'Tablet',500.00,'2024-03-01'),(1,'Laptop',1200.00,'2024-01-01'),(2,'Phone',800.00,'2024-01-01'),(3,'Tablet',600.00,'2024-01-01'),(1,'Laptop',1100.00,'2024-02-01'),(2,'Phone',750.00,'2024-02-01'),(3,'Tablet',550.00,'2024-02-01'),(1,'Laptop',1000.00,'2024-03-01'),(2,'Phone',700.00,'2024-03-01'),(3,'Tablet',500.00,'2024-03-01');
/*!40000 ALTER TABLE `product_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `product_id` int DEFAULT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Product A',50.00),(2,'Product B',60.00),(3,'Product C',50.00),(4,'Product D',70.00);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_2`
--

DROP TABLE IF EXISTS `products_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_2` (
  `product_id` int DEFAULT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_2`
--

LOCK TABLES `products_2` WRITE;
/*!40000 ALTER TABLE `products_2` DISABLE KEYS */;
INSERT INTO `products_2` VALUES (1,'Laptop',1200.00),(2,'Phone',800.00),(3,'Tablet',600.00),(4,'Headphones',800.00),(5,'Keyboard',50.00),(6,'Mouse',30.00),(7,'Monitor',400.00),(8,'Printer',200.00);
/*!40000 ALTER TABLE `products_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `product_id` int DEFAULT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `sales_amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,'Product A',1000.00),(2,'Product B',1500.00),(3,'Product C',1200.00),(4,'Product D',1300.00);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_quantity`
--

DROP TABLE IF EXISTS `sales_quantity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_quantity` (
  `sale_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_quantity`
--

LOCK TABLES `sales_quantity` WRITE;
/*!40000 ALTER TABLE `sales_quantity` DISABLE KEYS */;
INSERT INTO `sales_quantity` VALUES (1,101,5,20.00),(2,102,3,15.00),(3,103,2,25.00),(4,101,2,18.00),(5,102,4,12.00);
/*!40000 ALTER TABLE `sales_quantity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_representatives`
--

DROP TABLE IF EXISTS `sales_representatives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_representatives` (
  `rep_id` int DEFAULT NULL,
  `rep_name` varchar(50) DEFAULT NULL,
  `sales_amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_representatives`
--

LOCK TABLES `sales_representatives` WRITE;
/*!40000 ALTER TABLE `sales_representatives` DISABLE KEYS */;
INSERT INTO `sales_representatives` VALUES (1,'Alice',10000.00),(2,'Bob',12000.00),(3,'Charlie',15000.00),(4,'David',9000.00),(5,'Michel',10000.00);
/*!40000 ALTER TABLE `sales_representatives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_representatives_target`
--

DROP TABLE IF EXISTS `sales_representatives_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_representatives_target` (
  `rep_id` int DEFAULT NULL,
  `rep_name` varchar(50) DEFAULT NULL,
  `target_sales` decimal(10,2) DEFAULT NULL,
  `achieved_sales` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_representatives_target`
--

LOCK TABLES `sales_representatives_target` WRITE;
/*!40000 ALTER TABLE `sales_representatives_target` DISABLE KEYS */;
INSERT INTO `sales_representatives_target` VALUES (1,'Alice',100000.00,95000.00),(2,'Bob',120000.00,125000.00),(3,'Charlie',90000.00,85000.00),(4,'David',110000.00,100000.00);
/*!40000 ALTER TABLE `sales_representatives_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_transaction`
--

DROP TABLE IF EXISTS `sales_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_transaction` (
  `transaction_id` int DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `sales_amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_transaction`
--

LOCK TABLES `sales_transaction` WRITE;
/*!40000 ALTER TABLE `sales_transaction` DISABLE KEYS */;
INSERT INTO `sales_transaction` VALUES (1,'2024-01-01',1000.00),(2,'2024-01-05',1200.00),(3,'2024-01-10',900.00),(4,'2024-01-15',1500.00);
/*!40000 ALTER TABLE `sales_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stocks`
--

DROP TABLE IF EXISTS `stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stocks` (
  `stock_id` int DEFAULT NULL,
  `date` date DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stocks`
--

LOCK TABLES `stocks` WRITE;
/*!40000 ALTER TABLE `stocks` DISABLE KEYS */;
INSERT INTO `stocks` VALUES (1,'2024-01-01',100.00),(2,'2024-01-02',120.00),(1,'2024-01-03',90.00),(2,'2024-01-04',150.00);
/*!40000 ALTER TABLE `stocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `student_id` int DEFAULT NULL,
  `student_name` varchar(50) DEFAULT NULL,
  `exam_id` int DEFAULT NULL,
  `exam_score` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'Alice',1,85),(2,'Bob',2,78),(3,'Charlie',1,92),(4,'David',2,80),(5,'Eva',1,88),(6,'Frank',2,80),(7,'Grace',1,90);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_traffic`
--

DROP TABLE IF EXISTS `web_traffic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `web_traffic` (
  `page_id` int DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `page_views` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_traffic`
--

LOCK TABLES `web_traffic` WRITE;
/*!40000 ALTER TABLE `web_traffic` DISABLE KEYS */;
INSERT INTO `web_traffic` VALUES (1,'2024-01-01',100),(2,'2024-01-02',120),(1,'2024-01-03',90),(2,'2024-01-04',150);
/*!40000 ALTER TABLE `web_traffic` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-05 11:06:49
