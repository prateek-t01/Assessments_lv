##
##  Relative rank of each students compare to all the students in the class
##  In comparison to other students (or employee or product or etc.), where do you stand?
##

-- Example 1
/* calculate the percent rank of each student's exam score */

SELECT student_name, exam_score, PERCENT_RANK() OVER (ORDER BY exam_score) AS percent_ranks
FROM students;

-- Example 2
/*  calculate the percent rank of each product's price */
SELECT product_name, price, PERCENT_RANK() OVER (ORDER BY price) AS percent_ranks
FROM products;

-- Example 3
/*calculate the percent rank of each sales transaction's amount */

SELECT product_name, sales_amount, PERCENT_RANK() OVER (ORDER BY sales_amount) AS percent_ranks
FROM sales;

-- Example 4
/*calculate the percent rank of each employee's salary */
SELECT employee_name, salary, PERCENT_RANK() OVER (ORDER BY salary) AS percent_ranks
FROM employees;

-- Example 5
/* calculate the percent rank of each customer's total orders */
SELECT customer_name, total_orders, PERCENT_RANK() OVER (ORDER BY total_orders) AS percent_ranks
FROM customers;
