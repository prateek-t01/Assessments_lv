-- 1
select customerID, dataUsed from customerinteractions where dataUsed > 
(select AVG(dataUsed) from customerinteractions where month = 'March');

-- 2
SELECT DISTINCT CustomerID
FROM customerinteractions AS t1
WHERE 
    Month = 'March' 
    AND Year = 2024 
    AND CallDuration > (
        SELECT CallDuration 
        FROM customerinteractions AS t2
        WHERE Month = 'February' 
        AND Year = 2024 
        AND t1.CustomerID = t2.CustomerID
        LIMIT 1
    );

-- 3
SELECT DISTINCT CustomerID
FROM customerinteractions AS t1
WHERE 
    Month = 'February' 
    AND Year = 2024 
    AND MessageCount > (
        SELECT MessageCount 
        FROM customerinteractions AS t2
        WHERE Month = 'March' 
        AND Year = 2024 
        AND t1.CustomerID = t2.CustomerID
        LIMIT 1
    ) 
    AND DataUsed < (
        SELECT DataUsed 
        FROM customerinteractions AS t3
        WHERE Month = 'March' 
        AND Year = 2024 
        AND t1.CustomerID = t3.CustomerID
        LIMIT 1
    );

-- 4
SELECT SUM(TotalSalesAmount) AS TotalSales
FROM quarterlysales
WHERE ProductTypeID = 1;

-- 5
SELECT ProductTypeID, SUM(TotalSalesAmount) AS TotalSales
FROM quarterlysales
WHERE Quarter = 'Q1'
GROUP BY ProductTypeID
ORDER BY TotalSales DESC
LIMIT 1;

-- 6
SELECT AVG(TotalSalesAmount / UnitsSold) AS AverageSalesPerUnit
FROM quarterlysales;

-- 7
SELECT Region
FROM sectorenergyconsumption
WHERE EnergySource IN ('solar', 'wind')
  AND Month = 'March'
  AND Year = 2024
GROUP BY Region
HAVING AVG(ConsumptionKWh) > (
    SELECT AVG(ConsumptionKWh)
    FROM sectorenergyconsumption
    WHERE EnergySource IN ('solar', 'wind')
      AND Month = 'March'
      AND Year = 2024
);

-- 8

SELECT Sector,
	CASE
		WHEN SUM(CASE WHEN Month = 'March' THEN ConsumptionKWh ELSE 0 END) > SUM(CASE WHEN Month = 'February' THEN ConsumptionKWh ELSE 0 END)
			THEN 'Increase'
		ELSE 'No Increase'
	END AS ConsumptionChange
FROM sectorenergyconsumption
WHERE Year = 2024
  AND Month IN ('February', 'March')
GROUP BY Sector;

-- 9

SELECT EnergySource,
       SUM(CASE WHEN EnergySource IN ('solar', 'wind') THEN ConsumptionKWh ELSE 0 END) AS RenewableEnergy,
       SUM(CASE WHEN EnergySource NOT IN ('solar', 'wind') THEN ConsumptionKWh ELSE 0 END) AS FossilFuels
FROM sectorenergyconsumption
WHERE Month = 'February'
  AND Year = 2024
GROUP BY EnergySource;

-- 10

SELECT *
FROM insuranceactivities
WHERE (FeedbackScore > (SELECT AVG(FeedbackScore) FROM insuranceactivities)
        OR ClaimsCount > (SELECT AVG(ClaimsCount) FROM insuranceactivities))
    AND Investigation = 'No';

-- 11

SELECT SUM(AnnualPremium) AS TotalPremium
FROM insuranceactivities
WHERE FeedbackScore > (SELECT AVG(FeedbackScore) FROM insuranceactivities)
    AND ClaimsCount >= 1;
    
-- 12

SELECT 
    distinct PolicyType,
    CASE 
        WHEN ClaimsCount > 0 THEN 'With Claims'
        ELSE 'No Claims'
    END AS ClaimSegment,
    AVG(FeedbackScore) AS AvgFeedbackScore
FROM insuranceactivities
GROUP BY PolicyType, 
         CASE 
            WHEN ClaimsCount > 0 THEN 'With Claims'
            ELSE 'No Claims'
         END;






