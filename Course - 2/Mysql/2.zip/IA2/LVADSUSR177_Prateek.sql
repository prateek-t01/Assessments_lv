-- 1
select machine_id 
from l1_maintenance_records 
where Month(maintenance_date) = 3
	and cost > 
			(select avg(cost) 
            from l1_maintenance_records);
            
-- 2
select 
count(maintenance_type) as maintenance_count,
maintenance_type
from l1_maintenance_records 
group by maintenance_type
ORDER BY  maintenance_count desc limit 1;

-- 3
select 
technician_name,count(technician_name) as Technician_count
from l1_maintenance_records
group by technician_name
order by Technician_count desc limit 1;
 -- (NOt Done)
select technician_name from l1_maintenance_records
having avg(cost) > (select avg(cost) from l1_maintenance_records);

-- 4
-- not done
select product_id, 
incident_count_pre_update,
incident_count_post_update,
(incident_count_post_update-avg(incident_count_post_update)) as reduction
from l2_updates
group by product_id;

-- 5
select update_id, user_feedback_score,
(incident_count_post_update - incident_count_pre_update)
as decrease
from l2_updates
order by user_feedback_score desc limit 1;

-- 6
select distinct product_id, update_id,
round(abs(((incident_count_post_update/incident_count_pre_update)*100)-100),0) as Percentage_incident_decline
from l2_updates
order by update_id;
-- Product_Id p100 has least percentage of decline in incident count.

-- 7

create or replace view patient_record
as
select 
	p.patient_id,
	p.patient_name,
	f.facility_name,
    t.treatment,
	v.reason_for_visit,
	t.outcome
from 
l3_patients p
join 
l3_visits v on p.patient_id = v.patient_id
join
l3_treatments t on v.visit_id = t.visit_id
join
l3_facilities f on v.facility_id = f.facility_id;

select * from patient_record;

-- 8
 -- not done
select 
	f.facility_name,
    v.reason_for_visit,
    count(v.facility_id) as count
from l3_visits v
inner join l3_facilities f
on v.facility_id = f.facility_id
group by v.reason_for_visit;

-- 9

select 
p.patient_id,
p.insurance_provider,
t.outcome
from l3_patients p
left join l3_visits v
on p.patient_id = v.patient_id
join l3_treatments t
on v.visit_id = t.visit_id
where t.outcome = "Complicated";

-- 10
-- not done
select 
category,
group_concat(product_name,",") as products,
(select sum(quantity) from l4_sales group by l4_products.category)
from l4_products
group by category;

-- 11
create or replace view regional_analysis
as

select 
s1.sale_id,
s1.quantity,
s2.region,
p.price,
(s1.quantity*p.price) as sales
from l4_sales s1
left join l4_stores s2
on s1.store_id = s2.store_id
right join l4_products p
on s1.product_id = p.product_id
order by sales desc;

select * from regional_analysis;

-- 12

select 
p.product_id
from l4_products p
left join l4_sales s
using(product_id)

union

select
s.product_id
from l4_products p
right join l4_sales s
using(product_id)
