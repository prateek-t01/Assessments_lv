CREATE TABLE sales (
    sale_id INT,
    product_name VARCHAR(255), -- Adjust the length as needed
    quantity INT,
    price_each DECIMAL(10, 2), -- Adjust precision and scale as needed
    sale_date DATE,
    customer_id INT
);
INSERT INTO sales (sale_id, product_name, quantity, price_each, sale_date, customer_id) VALUES
(1, 'Wireless Mouse', 2, 29.99, '2023-01-10', 101),
(2, 'Bluetooth Keyboard', 1, 49.99, '2023-01-12', 102),
(3, 'USB-C Charging Cable', 3, 19.99, '2023-02-15', 103),
(4, 'Gaming Monitor', 1, 259.99, '2023-02-20', 104),
(5, 'Smartphone Case', 4, 15.99, '2023-03-05', 105),
(6, 'Headphones', 2, 79.99, '2023-03-08', 106),
(7, 'Laptop Stand', 1, 39.99, '2023-03-15', 107),
(8, 'External Hard Drive', 1, 89.99, '2023-04-02', 108),
(9, 'Wireless Earbuds', 3, 69.99, '2023-04-10', 109),
(10, 'Portable Charger', 2, 29.99, '2023-04-18', 110),
(11, 'Webcam', 1, 59.99, '2023-05-01', 111),
(12, 'Printer', 1, 149.99, '2023-05-10', 112),
(13, 'Tablet Case', 2, 19.99, '2023-05-18', 113);

select 
	sale_id, 
    product_name, 
    quantity, 
    price_each, 
    sale_date, 
    customer_id, 
    (quantity * price_each) as total_Sales 
from 
	sales;
    
select * from sales
   where quantity > 2;

select * from sales
where monthname(sale_date) = "February" and
(quantity * price_each) > 100;

SELECT 
    CONCAT(product_name, ' - Qty: ', quantity) AS product_quantity,
    price_each,
    sale_date,
    customer_id
FROM 
    sales;
    
select * from sales
where customer_id in (101, 103, 105);

select * from sales 
where sale_date between '2023-01-01' and '2023-03-31';

select * from sales 
where
product_name like "%USB%";

SELECT *
FROM sales
WHERE (customer_id & 1) = 1;





