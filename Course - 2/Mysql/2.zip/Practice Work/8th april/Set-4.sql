-- Create customers table
CREATE TABLE customers (
    customer_id INT,
    name VARCHAR(255),
    email VARCHAR(255),
    country VARCHAR(255)
);

-- Insert sample data into customers table
INSERT INTO customers (customer_id, name, email, country) VALUES
(101, 'John Doe', 'johndoe@example.com', 'USA'),
(102, 'Jane Smith', 'janesmith@example.com', 'Canada'),
(103, 'Carlos Slim', 'carlosslim@example.com', 'Mexico'),
(104, 'Marie Curie', 'mariecurie@example.com', 'France'),
(105, 'Liu Wei', 'liuwei@example.com', 'China'),
(106, 'Michael Johnson', 'michael@example.com', 'USA'),
(107, 'Sophie Martin', 'sophie@example.com', 'Canada'),
(108, 'Diego Rivera', 'diego@example.com', 'Mexico'),
(109, 'Elena Dupont', 'elena@example.com', 'France'),
(110, 'Li Na', 'lina@example.com', 'China'),
(111, 'David Lee', 'david@example.com', 'USA'),
(112, 'Emma Taylor', 'emma@example.com', 'Canada'),
(113, 'Fernando Gonzalez', 'fernando@example.com', 'Mexico');

-- Create orders table
CREATE TABLE orders (
    order_id INT,
    customer_id INT,
    order_date DATE,
    total_amount DECIMAL(10, 2)
);

-- Insert sample data into orders table
INSERT INTO orders (order_id, customer_id, order_date, total_amount) VALUES
(1, 101, '2023-03-15', 200.00),
(2, 103, '2023-03-16', 150.00),
(3, 101, '2023-03-17', 50.00),
(4, 102, '2023-03-18', 100.00),
(5, 104, '2023-03-19', 250.00),
(6, 101, '2023-03-20', 300.00),
(7, 103, '2023-03-21', 180.00),
(8, 105, '2023-03-22', 210.00),
(9, 102, '2023-03-23', 80.00),
(10, 104, '2023-03-24', 120.00),
(11, 101, '2023-03-25', 90.00),
(12, 103, '2023-03-26', 400.00),
(13, 105, '2023-03-27', 150.00);

SELECT 
    country, 
    GROUP_CONCAT(name ORDER BY name ASC SEPARATOR ', ') AS customer_names
FROM 
    customers
GROUP BY 
    country;

SELECT 
    order_date,
    SUM(total_amount) AS total_order_amount
FROM 
    orders
GROUP BY 
    order_date WITH ROLLUP;
    
SELECT 
    country,
    COUNT(customer_id) AS total_customers,
    GROUP_CONCAT(name ORDER BY name SEPARATOR ', ') AS customer_names
FROM 
    customers
GROUP BY 
    country;
    
SELECT 
    CASE 
        WHEN c.country IS NULL THEN 'Total' 
        ELSE c.country 
    END AS country,
    CASE 
        WHEN o.customer_id IS NULL THEN 'Total' 
        ELSE CONCAT(MAX(c.name), ' (ID: ', CAST(o.customer_id AS CHAR), ')') 
    END AS customer,
    SUM(o.total_amount) AS total_amount
FROM 
    orders o
JOIN 
    customers c ON o.customer_id = c.customer_id
GROUP BY 
    c.country, o.customer_id WITH ROLLUP;

SELECT 
    customer_id,
    CONCAT('Orders: ', GROUP_CONCAT(order_id ORDER BY order_id)) AS concatenated_orders
FROM 
    orders
GROUP BY 
    customer_id
HAVING 
    COUNT(*) > 1;

SELECT 
    customer_id,
    CONCAT('Customer ', customer_id) AS customer,
    SUM(total_amount) AS total_sales
FROM 
    orders
GROUP BY 
    customer_id WITH ROLLUP
HAVING 
    total_sales > 100 ;

SELECT 
    GROUP_CONCAT(DISTINCT country ORDER BY country) AS unique_countries
FROM 
    customers;






SELECT 
    DATE(order_date) AS day,
    MONTH(order_date) AS month,
    SUM(total_amount) AS total_amount
FROM 
    orders
GROUP BY 
    day, month WITH ROLLUP;




