select * from transactions 
where transaction_type = "Withdrawal";

select * from transactions 
order by amount desc;

select account_id, sum(amount) from transactions 
group by account_id;

select 
account_id,transaction_type, sum(amount) 
from 
transactions
where transaction_type = "deposit"
group by account_id
having (sum(amount)) > 1000;

SELECT account_id, transaction_type, SUM(amount) AS total_withdrawn
FROM transactions
WHERE transaction_type = 'Withdrawal'
GROUP BY account_id
HAVING total_withdrawn > 100;

SELECT *
FROM transactions
WHERE transaction_type = 'Deposit' AND amount > 200
ORDER BY transaction_date DESC;

SELECT *
FROM transactions
WHERE (YEAR(transaction_date) = 2023 AND MONTH(transaction_date) = 2)
   OR amount > 400;
   
SELECT 
    transaction_type,
    AVG(amount) AS average_transaction_amount
FROM 
    transactions
GROUP BY 
    transaction_type;

SELECT 
    account_id, 
    COUNT(*) AS total_transactions
FROM 
    transactions
GROUP BY 
    account_id
HAVING 
    COUNT(*) > 2;

SELECT 
    account_id, 
    SUM(amount) AS total_amount
FROM 
    transactions
GROUP BY 
    account_id
ORDER BY 
    total_amount DESC;





