
create table books (
book_id INT,
title VARCHAR(25),
author VARCHAR(25),
publication_year INT,
genre VARCHAR(25),
price float(2));

insert into books (book_id, title, author, publication_year, genre, price)
values
(1, "The Great Gatsby", "F. Scott Fitzgerald", 1925, "Fiction", 14.99),
(2, "War and Peace", "Leo Tolstoy", 1869, "Historical", 19.99),
 (3, "Moby Dick", "Herman Melville", 1851, "Adventure", 12.99),
 (4, "1984", "George Orwell", 1949, "Dystopian", 9.99),
(5, "The Catcher in the Rye", "J.D. Salinger", 1951, "Fiction", 8.99),
(6, 'To Kill a Mockingbird', 'Harper Lee', 1960, 'Fiction', 12.99),
(7, '1984', 'George Orwell', 1949, 'Dystopian', 9.99),
(8, 'The Great Gatsby', 'F. Scott Fitzgerald', 1925, 'Classics', 10.50),
(9, 'Pride and Prejudice', 'Jane Austen', 1813, 'Romance', 8.50),
(10, 'Harry Potter and the Sorcerer''s Stone', 'J.K. Rowling', 1997, 'Fantasy', 15.99),
(11, 'The Catcher in the Rye', 'J.D. Salinger', 1951, 'Literary Fiction', 11.25),
(12, 'Lord of the Rings: The Fellowship of the Ring', 'J.R.R. Tolkien', 1954, 'Fantasy', 14.75),
(13, 'The Hobbit', 'J.R.R. Tolkien', 1937, 'Fantasy', 13.25),
(14, 'Animal Farm', 'George Orwell', 1945, 'Political Satire', 9.75),
(15, 'The Da Vinci Code', 'Dan Brown', 2003, 'Mystery', 12.99);


create view fiction_books 
as
select title, publication_year from books
where genre = "Fiction";

select title from fiction_books
where publication_year > 1930;

CREATE OR REPLACE VIEW fiction_books AS
SELECT title, author, publication_year 
FROM books
WHERE genre = 'Fiction';

drop view fiction_books;


