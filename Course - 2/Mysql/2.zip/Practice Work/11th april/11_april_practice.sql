/*
employees table columns: employee_id, first_name, last_name, salary, department_id, job_id, manager_id, hire_date
departments table columns: department_id, department_name, manager_id, location_id
locations table columns: location_id, city, country_id
job_history table columns: location_id, city, country_id
jobs table columns: job_id, job_title, min_salary, max_salary
*/

-- 1
select first_name, last_name
from employees 
where salary > (
				select * 
                from employees 
				where employee_id = 163
                );

-- 2
 select first_name, last_name, department_id,job_id
 from employees 
 where designation = (
						select designation
                        from employees
                        where employee_id = 169
                        );
           
-- 3
select first_name, last_name, department_id
from employees
where salary = any (
				select min(salary)
                from employees
                );
                
-- 4
select employee_id, first_name, last_name
from employees
where salary > (
				select avg(salary)
                from employees
                );

-- 5

SELECT 
	e.employee_id, 
	concat(e.first_name, " ", e.last_name) as employee_name,
    e.manager_id, 
    concat(m.first_name, " ", m.last_name) as manager_name,
    e.salary
FROM employees e
LEFT JOIN employees m 
ON e.manager_id = m.employee_id
where m.first_name = 'Payam';

-- 6

select 
	d.department_id,
    e.first_name as name,
    e.job_ID,
    d.department_name
from departments d
left join employees e
on d.department_id = e.department_id
where d.department_name = "Finance";

-- 7

select * from employees
where salary = 3000
and manager_id = 121;

-- 8

select * 
from employees
having employee_id in (134, 159, 183);

-- 9
select *
from employees
having salary between 3500 and 5000;

-- 10
select *
from employees
having salary between 
	(select min(salary) from employees) and 5000;

-- 11
select 
	d.department_id,
    e.first_name as name,
    e.job_ID,
    d.department_name
from departments d
left join employees e
on d.department_id = e.department_id
where e.manager_id between 100 and 200;

-- 12
SELECT * 
FROM (
    SELECT *, RANK() OVER (ORDER BY salary DESC) AS salary_rank
    FROM employees
) ranked_employees
WHERE salary_rank = 2;

-- 13
select 	
	first_name,
    last_name,
    hire_date
from
	employees
where employee_id in (
						select 
							employee_id
						from 
							employees
						where
							first_name = 'Clara'
						);

-- 14
SELECT employee_id, first_name, last_name
FROM employees
WHERE department_id IN (
    SELECT department_id
    FROM employees
    WHERE first_name LIKE '%T%'
);

-- 15

SELECT employee_id, first_name, salary
FROM employees
WHERE salary > (
				SELECT 
					AVG(salary)
				FROM
					employees
				)
AND 
	department_id in (
					SELECT
						department_id
					FROM
						employees
					WHERE
						first_name
					LIKE
						'%J%'
					);

-- 16

select 
	e.first_name,
    e.last_name,
    e.employee_id,
    e.job_id
from
	employees e
join departments d
on e.department_id = d.department_id
join locations l
on l.location_id  = d.location_id
where l.city = 'Toronto';

-- 17

SELECT 
    e.employee_id,
    e.first_name,
    e.last_name,
    e.job_id
FROM 
    employees e
WHERE 
    e.salary < (
        SELECT 
            MAX(salary)
        FROM 
            employees
        WHERE 
            job_id = (SELECT job_id FROM jobs WHERE job_title = 'MK_MAN')
    );

-- 18
SELECT 
    e.employee_id,
    e.first_name,
    e.last_name,
    e.job_id
FROM 
    employees e
WHERE 
    e.salary < (
        SELECT 
            MAX(salary)
        FROM 
            employees
        WHERE 
            job_id = (SELECT job_id FROM jobs WHERE job_title = 'MK_MAN')
    )
    AND e.job_id != (SELECT job_id FROM jobs WHERE job_title = 'MK_MAN');

-- 19
SELECT 
    e.employee_id,
    e.first_name,
    e.last_name,
    e.job_id
FROM 
    employees e
WHERE 
    e.salary > (
        SELECT 
            MAX(salary)
        FROM 
            employees
        WHERE 
            job_id = (SELECT job_id FROM jobs WHERE job_title = 'PU_MAN')
    )
    AND e.job_id != (SELECT job_id FROM jobs WHERE job_title = 'PU_MAN');

-- 20
SELECT 
    e.employee_id,
    e.first_name,
    e.last_name,
    e.job_id
FROM 
    employees e
WHERE 
    e.salary > (
        SELECT 
            AVG(salary)
        FROM 
            employees
    );

-- 21

select 
	e.first_name,
    e.last_name,
    d.department_id
from employees e
left join departments d
using (department_id)
where salary > 3700;

-- 22
select 
	department_id,
    sum(salary) as total_salary
from employees 
where department_id in (
						select 
							department_id 
						from 
                        departments
                        )
GROUP BY
	department_id;
    
-- 23

select
	employee_id,
    concat(first_name," ",last_name) as name,
    case
		when job_id = 'ST_MAN' then "SALESMAN"
        when job_id = 'IT_PROG' then 'DEVELOPER'
		else job_id
	end as modified_job_id
from employees
where job_id IN ('ST_MAN', 'IT_PROG');

-- 24
select
	employee_id,
    concat(first_name," ",last_name) as name,
    salary,
    case 
        when salary > (SELECT AVG(salary) FROM employees) then "HIGH"
        else "LOW"
	end as SalaryStatus
from employees;

-- 25

select
	employee_id,
    concat(first_name," ",last_name) as name,
    Salary as SalaryDrawn,
    (SELECT AVG(salary) FROM employees) as AvgCompare,
    case 
        when salary > (SELECT AVG(salary) FROM employees) then "HIGH"
        else "LOW"
	end as SalaryStatus
    from employees;
    
-- 26
SELECT DISTINCT department_name
FROM departments
INNER JOIN employees ON departments.department_id = employees.department_id;

-- 27
SELECT DISTINCT e.first_name
FROM employees e
JOIN departments d ON e.department_id = d.department_id
JOIN locations l ON d.location_id = l.location_id
WHERE l.country_id = 'UK';

-- 28
SELECT DISTINCT e.last_name
FROM employees e
JOIN departments d ON e.department_id = d.department_id
WHERE d.department_name LIKE 'IT%' -- assuming department names start with 'IT'
AND e.salary > (SELECT AVG(salary) FROM employees WHERE department_id = d.department_id);

-- 29
select
	first_name,
    last_name,
    Salary
from employees
where last_name in (select last_name 
					from employees
                    where salary < (select salary
									from employees
                                    where last_name = "Ozer"
                                    )
					)
order by last_name desc;

-- 30
select
	e.first_name,
    e.last_name
from employees e
join departments d
on e.department_id = d.department_id
where e.salary > 0.5 * (
        SELECT 
            SUM(salary)
        FROM 
            employees
        WHERE 
            department_id = e.department_id
    );
    
-- 32

select * from employees
where job_id = "MANAGER";

-- 33
select * from employees
where job_id = "MANAGER";

-- 34

select 
	e.employee_id,
    e.first_name,
    e.last_name,
    e.salary,
    d.department_name,
    l.city
from employees e
left join departments d
on e.department_id = d.department_id
left join locations l
on d.location_id = l.location_id
where salary = (select
					max(salary)
					from employees)
 and hire_date BETWEEN '2022-01-01' and '2023-12-31';
 
 -- 35
select 
	d.department_id,
    d.department_name
from departments d
left join locations l
on d.location_id = l.location_id
where city = 'London';

-- 36
select
	first_name,
    last_name,
    salary,
    department_id
from employees
where salary > (
				select avg(salary) from employees)
order by salary desc;

-- 37
select
	first_name,
    last_name,
    department_id,
    salary
from employees
left join departments
using(department_id)
where salary > (
	select max(salary) 
    from departments 
    where department_id = 40)
;

-- 38
select
	department_name,
    department_id
from departments
left join locations
using(location_id)
where location_id = (
	select location_id 
		from departments
        WHERE department_id = 40);
        
-- 39
select
	first_name,
    last_name,
    salary,
    department_id
from employees
where department_id = (
	Select department_id 
	from employees 
    where employee_id = 201);

-- 40
select
	first_name,
    last_name,
    department_id,
    salary
from employees
left join departments
using(department_id)
where salary = (
	select salary
    from departments 
    where department_id = 40)
;

-- 41

select
	first_name,
    last_name,
    department_id
from employees
left join departments
using (department_id)
where departments.department_name = 'Marketing';

-- 42
select
	first_name,
    last_name,
    salary,
    department_id
from employees
where salary > (
	select min(salary) 
	from employees 
    where department_id = 40);
    
-- 43
select
	first_name,
    last_name,
    hire_date
from employees
where hire_date > (
	select hire_date 
	from employees 
    where employee_id = 165);
    
-- 44

select
	first_name,
    last_name,
    salary,
    department_id
from employees
where salary < (
	select min(salary) 
	from employees 
    where department_id = 70);
    
-- 45
select
	first_name,
    last_name,
    salary,
    department_id
from employees
where salary < (
	select avg(salary) 
    from employees)
and department_id = (
	select department_id 
    from employees 
    where last_name = 'Laura');
    
-- 46
select
	first_name,
    last_name,
    salary,
    department_id
from employees
left join departments
using (department_id)
left join locations
using(location_id)
where city = 'London';

-- 47
select city from locations
left join departments using (location_id)
left join employees using (department_id)
where employee_id = 134;

-- 48
select d.* from departments d
left join employees
using (department_id)
left join job_history
using (employee_id)
where salary >= 5000
and job_history.end_date is not null;

-- 49
select d.* from departments d
left join employees
using(department_id)
left join jobs
using (job_id)
where min_salary > 4000;

-- 50
SELECT 
    CONCAT(e.first_name, ' ', e.last_name) AS manager_name,
    e.department_id
FROM employees e
WHERE 
    e.employee_id IN (
        SELECT manager_id
        FROM employees
        WHERE manager_id IS NOT NULL
        GROUP BY manager_id
        HAVING 
            COUNT(*) >= 2
    );

-- 51
SELECT 
e.employee_id,
concat(e.first_name, ' ', e.last_name) as name,
j.*
FROM employees e
JOIN job_history jh ON e.employee_id = jh.employee_id
JOIN jobs j ON jh.job_id = j.job_id
WHERE j.job_title = 'SALESMAN';

-- 52
SELECT *
FROM employees
WHERE salary = (
    SELECT MIN(salary)
    FROM employees
    WHERE salary > (
        SELECT MIN(salary)
        FROM employees
    )
);

-- 53
SELECT *
FROM departments
WHERE manager_id = (
    SELECT employee_id
    FROM employees
    WHERE first_name = 'Susan' AND job_id = 'MANAGER'
);

-- 54
SELECT 
    department_id,
    CONCAT(first_name, ' ', last_name) AS employee_name,
    salary
FROM (
    SELECT 
        department_id,
        first_name,
        last_name,
        salary,
        ROW_NUMBER() OVER (PARTITION BY department_id ORDER BY salary DESC) AS salary_rank
    FROM 
        employees
) AS ranked_employees
WHERE 
    salary_rank = 1;

-- 55
SELECT *
FROM employees e
LEFT JOIN job_history jh ON e.employee_id = jh.employee_id
WHERE jh.employee_id IS NULL;























