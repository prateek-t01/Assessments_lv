-- Fetch employee name and department name that they belong to

select e.emp_name, d.dept_name
from employee e
join department d
using(dept_id);

-- fetch all the employee names

select e.emp_name, d.dept_name
from employee e
left join department d
using(dept_id);

select e.emp_name, d.dept_name
from employee e
right join department d
using(dept_id);

-- fetch details of ALL employees : managers, 
-- departments and projects they work on

select e.emp_name, d.dept_name, m.manager_name, p.project_name
from employee e
left join department d using(dept_id)
inner join manager m using (manager_id)
left join project p on e.emp_id = p.team_member_id or e.manager_id = p.team_member_id;

-- inner join - matching records
select e.emp_name, d.dept_name
from employee e
inner join department d 
using(dept_id);

-- Left Join - inner join + everything on the left table
select e.emp_name, d.dept_name
from employee e
left join department d 
using(dept_id);

-- right Join

select e.emp_name, d.dept_name
from employee e
right join department d 
using(dept_id);

-- full join - remaining left table + remaining right table

SELECT e.emp_name, d.dept_name
FROM employee e
LEFT JOIN department d ON e.dept_id = d.dept_id

UNION

SELECT e.emp_name, d.dept_name
FROM employee e
RIGHT JOIN department d ON e.dept_id = d.dept_id;

-- cross join - returns a cartesian product - match all the record from both table
-- no join condition needed
select e.emp_name, d.dept_name
from employee e
cross join department d;

-- natural join - join condition decided by sql

select d.dept_name, GROUP_CONCAT(e.emp_name, ",") as employee_name
from department d
right join employee e
using (dept_id)
group by dept_name;
