#
# USe DSAI_DEMO4 Schema 
#
#

# Example 1:
-- data transformation
-- SQL query transforms job titles based on employee experience.

SELECT 
    employee_name,
    CASE
        WHEN years_of_experience > 5 THEN CONCAT('Senior ', job_title)
        ELSE job_title
    END AS transformed_job_title,
    years_of_experience
FROM employees_details;

# Example 2:
-- Data Filtration
-- SQL query filters products based on availability status: 'Available' or 'Out of Stock'.

SELECT 
    product_name,
    CASE
        WHEN quantity > 0 THEN 'Available'
        ELSE 'Out of Stock'
    END AS availability_status,
    quantity
FROM products_inventory;


# Example 4:
-- Ordering: Define custom sorting logic for query results
-- SQL query retrieves employee names and job titles, sorted based on custom sequence: 'Manager' first, 'Developer' second, and other titles alphabetically.

SELECT employee_name, job_title
FROM employees_details
ORDER BY 
    CASE 
        WHEN job_title = 'Manager' THEN 1
        WHEN job_title = 'Developer' THEN 2
        ELSE 3
    END,
    job_title;
