##
##
##  DEMO_DAY3
##
## 


# Example 1:
 #Seller Email List by Country:
-- Question: Generate a list of emails for sellers in each country.
 
 SELECT country, GROUP_CONCAT(email) AS email_list
   FROM sellers
   GROUP BY country;

-- Example 2:
-- Seller Product Portfolio:
   #Question: Display each seller along with the list of products they are selling.
 
   SELECT seller_name, GROUP_CONCAT(product_name) AS products_sold
   FROM sellers
   JOIN products ON sellers.seller_id = products.seller_id
   GROUP BY seller_name;

# Example 3:
 #Popular Product Categories:
-- Question: List each product category along with the list of products in that category.
     
SELECT category, GROUP_CONCAT(product_name) AS products_in_category
   FROM products
   GROUP BY category;


# Example 4:
-- Seller Rating Analysis:
   #Question: Display each seller's name along with their average rating.
     
SELECT seller_name, AVG(rating) AS average_rating
   FROM sellers
   JOIN products ON sellers.seller_id = products.seller_id
   JOIN product_reviews ON products.product_id = product_reviews.product_id
   GROUP BY seller_name;

   
# Example 5:
-- Product Review Comments:
   #Question: Show each product along with the review IDs and usernames of users who have reviewed the product.
   
  SELECT product_name, GROUP_CONCAT(review_id) AS review_ids, GROUP_CONCAT(user_id) AS user_ids
   FROM products
   JOIN product_reviews ON products.product_id = product_reviews.product_id
   GROUP BY product_name;


# Example 6:
-- Seller Collaboration Analysis:
   #Question: Display each seller along with the list of other sellers they have collaborated with.
   SELECT s1.seller_name AS seller_name, GROUP_CONCAT(s2.seller_name) AS collaborated_sellers
   FROM sellers AS s1
   JOIN sellers AS s2 ON s1.seller_id != s2.seller_id
   GROUP BY s1.seller_name;

 







