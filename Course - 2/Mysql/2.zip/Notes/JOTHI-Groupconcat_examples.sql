
#
# USe DSAI_DEMO4 Schema 
#
#

#Example 1
-- Please write an SQL query to generate a summary report that lists each employee's ID, name, and a concatenated string of their skills.
-- The query should be based on a table named 'employees' with columns 'employee_id', 'name', and 'skill'.

SELECT employee_id, employee_name, GROUP_CONCAT(skill) AS skills
FROM employees
GROUP BY employee_id, employee_name;


# Example 2:
-- Retrieve a summary report of products available in each category.
-- The query displays each category along with a concatenated list of the products it contains.

SELECT category_name, GROUP_CONCAT(product_name) AS products
FROM categories
JOIN products ON categories.category_id = products.category_id
GROUP BY category_name;

# Example 3:
-- Retrieve a report listing each article along with a concatenated list of its associated tags.

SELECT a.article_id, a.article_title, GROUP_CONCAT(t.tag_name) AS tags
FROM articles a
INNER JOIN article_tags at ON a.article_id = at.article_id
INNER JOIN tags t ON at.tag_id = t.tag_id
GROUP BY a.article_id, a.article_title;



 


