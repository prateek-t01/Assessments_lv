
#
# USe DSAI_DEMO4 Schema 
#
#



#Example 1:
-- Analyze sales performance by region and category, including subtotals for each region and a grand total.
   
   SELECT region, category, SUM(sales_amount) AS total_sales
   FROM sales
   GROUP BY region, category WITH ROLLUP;
   
   #Example 2:
   -- Analyze sales performance by region and category, including subtotals for each region and a grand total, with average sales amount.
 SELECT region, category, AVG(sales_amount) AS avg_sales
   FROM sales
   GROUP BY region, category WITH ROLLUP;
   


#Example 3:
-- Analyze product sales by month and category, including subtotals for each month and a grand total, with minimum, maximum & total sales amount.
   
   SELECT MONTH(transaction_date) AS month, category, MIN(sales_amount) AS min_sales, MAX(sales_amount) AS max_sales, SUM(sales_amount) AS total_sales
   FROM sales_trans
   GROUP BY MONTH(transaction_date), category WITH ROLLUP;
   
   #Example 4:
  -- Analyze customer purchases by product and region, including subtotals for each product and a grand total, with count of purchases.
  
   SELECT region, product, COUNT(purchase_amount) AS purchase_count
   FROM purchases
   GROUP BY region, product WITH ROLLUP;
