##
##
##  DEMO_DAY3
##
## 


#Question1
-- Sales Insights:
-- Question: How can we analyze sales trends within the online automotive marketplace by brand and quarter?
SELECT 
    brand,
    CONCAT('Q', QUARTER(sale_date)) AS sales_quarter,
    SUM(total_revenue) AS total_revenue
FROM 
    sales s
JOIN 
    models m ON s.model_id = m.model_id
GROUP BY 
    brand, sales_quarter
WITH ROLLUP;

#Question2
-- Production Efficiency Analysis:
-- Question: How would you assess production efficiency across different brands and quarters in the automotive industry?
SELECT 
    brand,
    CONCAT('Q', QUARTER(production_date)) AS production_quarter,
    SUM(quantity_produced) AS total_quantity_produced,
    AVG(production_cost) AS avg_production_cost
FROM 
    production p
JOIN 
    models m ON p.model_id = m.model_id
GROUP BY 
    brand, production_quarter
WITH ROLLUP;

#Question3
-- Customer Engagement Evaluation:
-- Question: What insights can we derive from sales data regarding customer interactions with different car models, brands, and categories over time?
SELECT 
    brand,
    category,
    COUNT(*) AS total_sales
FROM 
    sales s
JOIN 
    models m ON s.model_id = m.model_id
GROUP BY 
    brand, category
WITH ROLLUP;

#Question4
-- Supply Chain Optimization:
-- Question: What steps can be taken to optimize production processes and supplier relationships based on production data?
SELECT 
    brand,
    CONCAT('Q', QUARTER(production_date)) AS production_quarter,
    MAX(quantity_produced) AS max_quantity_produced,
    MIN(production_cost) AS min_production_cost
FROM 
    production p
JOIN 
    models m ON p.model_id = m.model_id
GROUP BY 
    brand, production_quarter
WITH ROLLUP;

